package Model;

/**
 *
 * @author marga
 */
public class mdlSuperHeroes {
    
     public void AdicionarPoderCarrito(){
       
    }
    
    public void EliminarPoderCarrito(){
        
    }
    
    public void ConsultarPoderesCarrito(){
        
    }
    
}

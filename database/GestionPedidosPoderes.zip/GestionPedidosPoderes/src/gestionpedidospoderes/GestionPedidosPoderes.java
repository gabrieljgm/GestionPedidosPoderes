
package gestionpedidospoderes;

import View.NewJFrame;
import View.frmPrueba;
import View.frmSuperHeroes;

/**
 *
 * @author margarita forero
 */
public class GestionPedidosPoderes {

    public static void main(String[] args) {
      
        frmSuperHeroes frmSuperHeroes = new frmSuperHeroes();
       // new frmPrueba();
       // new NewJFrame();
      
    }
    
}
